(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a2a157dc._.js",
  "static/chunks/node_modules_lodash_20634561._.js",
  "static/chunks/node_modules_recharts_es6_0a962fb5._.js",
  "static/chunks/node_modules_37e81c07._.js"
],
    source: "dynamic"
});
